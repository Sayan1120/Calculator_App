package com.basic.arithmetic_operations.application.calculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etFirstValue, etSecondValue;
    TextView tvAnswer;
    AppCompatButton add, subtract, divide, multiply;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFirstValue = findViewById(R.id.edtFirstValue);
        etSecondValue = findViewById(R.id.edtSecondValue);

        tvAnswer = findViewById(R.id.tvAnswer);
        add = findViewById(R.id.btnAdd);
        subtract = findViewById(R.id.btnSubtract);
        divide = findViewById(R.id.btnDivide);
        multiply = findViewById(R.id.btnMultiply);

        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int firstValue, secondValue, answer;

                firstValue = Integer.parseInt(etFirstValue.getText().toString());
                secondValue = Integer.parseInt(etSecondValue.getText().toString());

                answer = firstValue + secondValue;

                tvAnswer.setText("Answer: " + answer);
            }
        });

        subtract.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int firstValue, secondValue, answer;

                firstValue = Integer.parseInt(etFirstValue.getText().toString());
                secondValue = Integer.parseInt(etSecondValue.getText().toString());

                answer = firstValue - secondValue;

                tvAnswer.setText("Answer: " + answer);
            }
        });
        divide.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int firstValue, secondValue, answer;

                firstValue = Integer.parseInt(etFirstValue.getText().toString());
                secondValue = Integer.parseInt(etSecondValue.getText().toString());

                answer = firstValue / secondValue;

                tvAnswer.setText("Answer: " + answer);
            }
        });
        multiply.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int firstValue, secondValue, answer;

                firstValue = Integer.parseInt(etFirstValue.getText().toString());
                secondValue = Integer.parseInt(etSecondValue.getText().toString());

                answer = firstValue * secondValue;

                tvAnswer.setText("Answer: " + answer);
            }
        });

    }
}